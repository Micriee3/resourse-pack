                #version 330

                #moj_import <minecraft:fog.glsl>
                #moj_import <minecraft:dynamictransforms.glsl>
                #moj_import <minecraft:projection.glsl>
                #moj_import <minecraft:sample_lightmap.glsl>
                #moj_import <minecraft:globals.glsl>

                in vec3 Position;
                in vec4 Color;
                in vec2 UV0;
                in ivec2 UV2;

                uniform sampler2D Sampler2;

                out float sphericalVertexDistance;
                out float cylindricalVertexDistance;
                out vec4 vertexColor;
                out vec2 texCoord0;
                const bool ORAXEN_ANIMATED_GLYPHS = true;
const int ORAXEN_ANIM_CONFIG_COUNT = 1;
const ivec2 ORAXEN_ANIM_CONFIGS[1] = ivec2[](
    ivec2(16, 16)
);


                    void main() {
                        vec3 pos = Position;
                        gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);
                        sphericalVertexDistance = fog_spherical_distance(pos);
                        cylindricalVertexDistance = fog_cylindrical_distance(pos);
                        texCoord0 = UV0;
                        vertexColor = Color * sample_lightmap(Sampler2, UV2);

                        int rInt = int(Color.r * 255.0 + 0.5);
                        int gRaw = int(Color.g * 255.0 + 0.5);
                        int bRaw = int(Color.b * 255.0 + 0.5);

                        // Check for animation color on the primary pass only.
                        //
                        // Shadow-pass colors are normal text colors divided by 4, so trying
                        // to detect animated shadow colors by RGB range causes many false
                        // positives (e.g. vanilla white text shadow 63,63,63). That makes
                        // regular text render without shadow. We intentionally only detect
                        // the primary animation marker here to keep vanilla shadows intact.
                        //
                        // A red value of 254 can occur in regular RGB gradients. To avoid
                        // treating those characters as animated glyphs, require the encoded
                        // FPS/loop and frame-count tuple to match an actually generated
                        // animated glyph, and require the frame index to be valid.
                        bool isPrimaryAnim = false;
                        if (ORAXEN_ANIMATED_GLYPHS && ORAXEN_ANIM_CONFIG_COUNT > 0 && rInt == 254) {
                            int candidateFrameIndex = bRaw & 0x0F;
                            int candidateTotalFrames = ((bRaw >> 4) & 0x0F) + 1;
                            if (candidateFrameIndex < candidateTotalFrames) {
                                for (int i = 0; i < ORAXEN_ANIM_CONFIG_COUNT; i++) {
                                    if (gRaw == ORAXEN_ANIM_CONFIGS[i].x && candidateTotalFrames == ORAXEN_ANIM_CONFIGS[i].y) {
                                        isPrimaryAnim = true;
                                        break;
                                    }
                                }
                            }
                        }

                        if (ORAXEN_ANIMATED_GLYPHS && isPrimaryAnim) {
                            int gInt = gRaw;
                            int bInt = bRaw;

                            bool loop = (gInt < 128);
                            float fps = max(1.0, float(gInt & 0x7F));
                            int frameIndex = bInt & 0x0F;
                            int totalFrames = ((bInt >> 4) & 0x0F) + 1;

                            float timeSeconds = (GameTime <= 1.0) ? (GameTime * 1200.0) : (GameTime / 20.0);
                            int rawFrame = int(floor(timeSeconds * fps));
                            int currentFrame = loop ? (rawFrame % totalFrames) : min(rawFrame, totalFrames - 1);

                            float visible = (frameIndex == currentFrame && isPrimaryAnim) ? 1.0 : 0.0;

                            vertexColor = vec4(1.0, 1.0, 1.0, visible) * sample_lightmap(Sampler2, UV2);
                        }
                        // WLU_TUTORIAL_HUD
    // Dedicated WLU font has ascent -8192; no ordinary text uses this range.
    if (Position.y > 8000.0 && Position.y < 9000.0) {
        ivec3 data = ivec3(round(Color.rgb * 255.0));
        int corner = gl_VertexID % 4;
        float x = 12.0 + float(data.r * 256 + data.g);
        float y = 12.0 + float(data.b / 16) * 14.0;
        x += (corner >= 2) ? 8.0 : 0.0;
        y += (corner == 1 || corner == 2) ? 12.0 : 0.0;
        vec2 size = vec2(2.0 / ProjMat[0][0], -2.0 / ProjMat[1][1]);
        gl_Position.xy = vec2(2.0 * x / size.x - 1.0, 1.0 - 2.0 * y / size.y) * gl_Position.w;
        sphericalVertexDistance = 0.0;
        cylindricalVertexDistance = 0.0;
        vec3 tint = data.b / 16 == 0 ? vec3(244,247,250) : (data.b / 16 == 3 ? vec3(14,255,0) : vec3(184,194,204));
        vertexColor = vec4(tint / 255.0, Color.a);
    }

}
